# BDR UI

Fase 0 de la suite fiscal de Business Done Right, S.L. Implementación local de `0.1.0`; la publicación privada y el PR todavía están pendientes de acceso a GitHub.

## Consumo

Nombre publicado autorizado: `@emprendurias-bdr/ui`. Mantén los imports lógicos `@bdr/ui` mediante un alias npm en las aplicaciones:

```json
{"dependencies":{"@bdr/ui":"npm:@emprendurias-bdr/ui@0.1.0"}}
```

Configura `@emprendurias-bdr:registry=https://npm.pkg.github.com` y autenticación del registro desde el entorno seguro. No introduzcas tokens en archivos versionados. React y React DOM son peer dependencies. La biblioteca no depende de Next.js, Vite ni Tauri.

```tsx
import '@bdr/ui/tokens.css';
import { Button, Field, AmountInput, Chip } from '@bdr/ui';
import { formatAmount } from '@bdr/ui/format'; // también apto en código de servidor

<Field label="Importe" hint="Usa coma decimal">
  <AmountInput value={amount} onChange={e => setAmount(e.target.value)} />
</Field>
```

`AmountInput` conserva el texto introducido, sin alterar importes del dominio. `NifInput` tampoco acredita validez de un NIF. `AccountInput` proporciona sugerencias nativas con `datalist`. Valida y convierte los datos en la capa de dominio de cada app.

`formatAmount` acepta decimales canónicos con punto (preferiblemente cadenas para conservar precisión arbitraria); agrupa miles, muestra dos decimales y signo Unicode `−`, y redondea exclusivamente para presentación. No lo uses como motor de cálculo fiscal. Rechaza valores no finitos, notación exponencial y entradas localizadas ambiguas. `formatDate` acepta una fecha civil ISO `YYYY-MM-DD` sin convertir zona horaria.

## Componentes y contratos

- `Button`: primary, dark, secondary, ghost, danger; busy bloquea el botón conservando su nombre.
- `Chip`: catálogo textual de borrador, pendiente, emitida, cuadra, revisar, error, vencido, anulada, XML preparado, en cola y estados de respuesta. La app debe aportar un estado confirmado por su dominio; el chip nunca deriva un envío o aceptación.
- `Field`: etiqueta persistente, ayuda y error enlazados al hijo con `id`/`aria-describedby`.
- `AmountInput`, `NifInput`, `AccountInput`: inputs accesibles; no ejecutan lógica contable o fiscal.
- `DataTable`: `@tanstack/react-table`, encabezados reales, caption y estado vacío; la aplicación define columnas, acciones, cifras y totales.
- `Stepper`: pasos pending/current/done/error con texto. El consumidor aporta los hitos verificados.
- `ValidationPanel`, `AuditTimeline`, `EmptyState`: información y estados del dominio sin inventarlos.
- `ConfirmDialog`: diálogo modal nativo con foco, Escape y checkbox «Lo entiendo». El consumidor controla `open`, `busy` y sus efectos.
- `AppShell`: BDR., selector de app/empresa/periodo, navegación, salto al contenido y menú plegable a menos de 1200 px. El consumidor controla los cambios y la búsqueda.
- `CommandPalette`: búsqueda, activación de acciones por teclado y Escape. La aplicación enlaza Ctrl K a `open`; la muestra incluye esa conexión.
- `AppearanceControls`: Claro/Oscuro/Sistema y Compacta/Cómoda. No impone una persistencia: ContaPro usará sus preferencias, CumpleFactura SQLite/cuenta. No se guardan tokens de sesión en el navegador.

Importa `tokens.css` una vez en la raíz. Establece `data-theme="light|dark|system"` y `data-density="compact|comfortable"` en `document.documentElement`; sin preferencia explícita, el CSS sigue al sistema. Compacta usa 40 px y cómoda 48 px de fila; objetivos interactivos mínimos de 44 px. Las apps fijan su densidad por defecto (ContaPro/modelos compacta; CumpleFactura cómoda).

Los siete archivos de fuentes WOFF2 y sus licencias OFL se empaquetan localmente. Los tokens proceden de `emprendurias-bdr/contapro/docs/mockups/_assets/app.css` (main ca8dbce); se mantienen colores, semánticos y tipografías. Se añaden bordes de control con contraste y estilos de producción sin las alturas fijas de las maquetas. Los colores de producto se reservan al identificador del shell, no a botones o estados.

## Desarrollo y verificación

Node 22 o superior, npm:

```sh
npm ci
npm test
npm run typecheck
npm run build
npm run build:showcase
npm run dev
# En otra terminal, con el servidor de muestra activo:
npm run test:browser
npm pack --dry-run
```

El test de navegador usa Chromium instalado por Playwright o `/usr/bin/chromium` cuando exista; puedes indicar `BDR_BROWSER_EXECUTABLE`. Examina ocho combinaciones de viewport (1024/1440), tema y densidad, ejecuta axe WCAG AA y guarda capturas/resultados en `docs/`. También comprueba confirmación, reapertura, Escape, paleta Ctrl K, cambio de tema del sistema y navegación plegable.

La muestra contiene únicamente datos ficticios y ninguna conexión fiscal. Las capturas de una galería no acreditan la integración de las apps. `docs/PHASE0.md` registra lo verificado y lo pendiente.

## Publicación

El repositorio remoto debe crearse como **privado** en `emprendurias-bdr/bdr-ui`, con `main` inicializado. La rama de esta fase es `feat/phase-0-shared-ui`. No publicar hasta confirmar la privacidad del repositorio y permisos del paquete. El `publishConfig` apunta exclusivamente a GitHub Packages con acceso restringido. El workflow de publicación se ejecuta al empujar una etiqueta `ui-v<versión>` o manualmente, y usa el token efímero de Actions. La etiqueta puede apuntar al commit de esta rama sin fusionarla; permite la primera publicación aunque main aún no contenga el workflow. Antes de crear la etiqueta, verifica los checks de ese mismo commit y la privacidad del repositorio. El workflow exige que la etiqueta y package.json coincidan. No publicar a npmjs.org. No fusionar el PR.

El código de BDR no se ofrece bajo licencia abierta (`UNLICENSED`). Las fuentes conservan sus licencias OFL incluidas.
